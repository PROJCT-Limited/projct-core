/* input.js — landing/select/graph pointer handling */

if (typeof pointer === 'undefined') window.pointer = {};
if (typeof draggingTag  === 'undefined') window.draggingTag  = null;
if (typeof draggingNode === 'undefined') window.draggingNode = null;

if (typeof pointer.id === 'undefined') pointer.id = null;
if (typeof pointer.dragging === 'undefined') pointer.dragging = false;
if (typeof pointer.startX === 'undefined') pointer.startX = 0;
if (typeof pointer.startY === 'undefined') pointer.startY = 0;

const DRAG_SLOP = 8;

// ---------- helpers you already had ----------
function uiWantsThisTouch(ev) {
  const t = ev && (ev.target || ev.srcElement);
  if (!t) return false;
  return !!t.closest('#mobileOverlay, #mobileTrigger, .mobile-close, .button-header, .header, a, button');
}
function overlayIsOpen() {
  const ov = document.getElementById('mobileOverlay');
  return ov && ov.classList.contains('open');
}
function isOnPlayButton(sx, sy) {
  if (!window.playBtn || typeof playBtn.x !== 'number') return false;
  const r = playBtn.r * 1.3;
  return dist(sx, sy, playBtn.x, playBtn.y) <= r;
}

// Landing should behave like select for tags
function inTagStage() { return window.mode === 'landing' || window.mode === 'select'; }

// Only treat clicks as "in panel" when a panel is actually shown (not on landing)
function isInPanelScreen(px, py) {
  if (window.mode === 'landing' || typeof LAYOUT === 'undefined') return false;
  if (LAYOUT === 'top')    return py < (topBarH || 0);
  if (LAYOUT === 'bottom') return py > height - (topBarH || 0);
  return px < (sideBarW || 0); // left
}

// Larger touch hit area
function touchHitRadius(node) {
  const sr = (node.baseR || 16) * (window.scaleFactor || 1);
  return Math.max(28, sr * 1.25);
}

// Pick a TAG (world coords)
function pickTagNodeAt(xw, yw) {
  if (!Array.isArray(window.tagNodes)) return null;
  let best = null, bestD = Infinity;
  for (const n of tagNodes) {
    const r = (pointer.isTouch ? touchHitRadius(n) / (window.scaleFactor || 1) : (n.baseR || 16));
    const d = dist(xw, yw, n.x, n.y);
    if (d <= r && d < bestD) { best = n; bestD = d; }
  }
  return best;
}

// Drop zone — screen coords
function inDrop(sx, sy) {
  const dz = window.dropZone;
  return !!(dz && sx >= dz.x && sx <= dz.x + dz.w && sy >= dz.y && sy <= dz.y + dz.h);
}

// ---------- mouse ----------
function mouseMoved() {
  pointer.x = mouseX; pointer.y = mouseY;
  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;
}

function mousePressed() {
  if (overlayIsOpen() || isInPanelScreen(mouseX, mouseY)) return;

  // we only care in landing/select/graph
  if (!inTagStage() && window.mode !== 'graph') return;

  pointer.isTouch = false;
  pointer.x = mouseX; pointer.y = mouseY;
  pointer.down = true; pointer.dragging = false; pointer.tapCandidate = true;
  pointer.startX = pointer.x; pointer.startY = pointer.y;

  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;

  if (inTagStage()) {
    draggingTag = pickTagNodeAt(pointer.worldX, pointer.worldY);
    if (draggingTag) {
      draggingTag.dragging = true;
      draggingTag.dx = pointer.worldX - draggingTag.x;
      draggingTag.dy = pointer.worldY - draggingTag.y;
    }
    return;
  }

  // graph mode
  draggingNode = null;
  if (Array.isArray(window.nodes)) {
    for (let i = nodes.length - 1; i >= 0; i--) {
      const n = nodes[i];
      const hit = (typeof n.isPointInside === 'function')
        ? n.isPointInside(pointer.worldX, pointer.worldY)
        : dist(pointer.worldX, pointer.worldY, n.x, n.y) <= (n.r || 12);
      if (hit) { draggingNode = n; n.fixed = true;
        n.offsetX = pointer.worldX - n.x; n.offsetY = pointer.worldY - n.y;
        window.activeNode = n; break; }
    }
  }
}

function mouseDragged() {
  if (!inTagStage() && window.mode !== 'graph') return;

  pointer.x = mouseX; pointer.y = mouseY;
  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;

  if (!pointer.dragging) {
    const dx = pointer.x - pointer.startX, dy = pointer.y - pointer.startY;
    if (dx*dx + dy*dy > DRAG_SLOP*DRAG_SLOP) pointer.dragging = true;
  }

  if (pointer.dragging && draggingTag) {
    draggingTag.x = pointer.worldX - draggingTag.dx;
    draggingTag.y = pointer.worldY - draggingTag.dy;
    draggingTag.vx = 0; draggingTag.vy = 0;
  } else if (pointer.dragging && window.mode === 'graph' && draggingNode) {
    draggingNode.x = pointer.worldX - draggingNode.offsetX;
    draggingNode.y = pointer.worldX ? pointer.worldY - draggingNode.offsetY : draggingNode.y;
    draggingNode.vx = 0; draggingNode.vy = 0;
  }
}

function mouseReleased() {
  if (!inTagStage() && window.mode !== 'graph') return;

  pointer.x = mouseX; pointer.y = mouseY;
  pointer.down = false; pointer.justReleased = true;

  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;

  if (draggingTag) {
    draggingTag.dragging = false;
    if (inDrop(pointer.x, pointer.y)) {
      const maxSel = (window.UI && Number.isFinite(UI.maxSelected)) ? UI.maxSelected : 3;
      if (!Array.isArray(window.selected)) window.selected = [];
      const already = selected.some(s => (s.label || s) === draggingTag.label);
      if (!already && selected.length < maxSel) {
        selected.push({ label: draggingTag.label, tags: draggingTag.tags?.slice?.() || [] });
      }
    }
    draggingTag = null;
    return;
  }

  if (window.mode === 'select') {
    if (isOnPlayButton(pointer.x, pointer.y) &&
        Array.isArray(window.selected) &&
        selected.length > 0 && selected.length <= ((window.UI && UI.maxSelected) || 3)) {
      if (typeof window.launchGraphFromSelection === 'function') window.launchGraphFromSelection();
    }
    return;
  }

  if (window.mode === 'graph') {
    if (draggingNode) {
      if (!pointer.dragging) {
        if (typeof window.refocusToByTags === 'function') window.refocusToByTags(draggingNode);
        else if (typeof window.refocusTo === 'function') window.refocusTo(draggingNode);
        if (typeof window.centerCameraOnNode === 'function') centerCameraOnNode(window.centerNode);
      }
      draggingNode.fixed = false; draggingNode = null;
      return;
    }

    if (Array.isArray(window.nodes)) {
      let tapped = null;
      for (const n of nodes) {
        const hit = (typeof n.isPointInside === 'function')
          ? n.isPointInside(pointer.worldX, pointer.worldY)
          : dist(pointer.worldX, pointer.worldY, n.x, n.y) <= (n.r || 12);
        if (hit) { tapped = n; break; }
      }
      if (tapped) {
        if (typeof window.refocusToByTags === 'function') window.refocusToByTags(tapped);
        else if (typeof window.refocusTo === 'function') window.refocusTo(tapped);
        if (typeof window.centerCameraOnNode === 'function') centerCameraOnNode(window.centerNode);
      }
    }
  }
}

// ---------- touch (mirrors mouse) ----------
function touchStarted(ev) {
  if (overlayIsOpen() || uiWantsThisTouch(ev)) return true;

  pointer.isTouch = true;
  if (!touches || touches.length === 0 || pointer.id !== null) return true;

  const t = touches[0];
  pointer.id = t.id;
  pointer.x = t.x; pointer.y = t.y;

  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;

  if (!inTagStage() && window.mode !== 'graph') return true;

  if (isInPanelScreen(pointer.x, pointer.y)) {
    draggingTag = null; draggingNode = null;
  } else if (inTagStage()) {
    draggingTag = pickTagNodeAt(pointer.worldX, pointer.worldY);
    if (draggingTag) {
      draggingTag.dragging = false;
      draggingTag.dx = pointer.worldX - draggingTag.x;
      draggingTag.dy = pointer.worldY - draggingTag.y;
    }
  } else {
    draggingNode = null;
    if (Array.isArray(window.nodes)) {
      for (let i = nodes.length - 1; i >= 0; i--) {
        const n = nodes[i];
        const hit = (typeof n.isPointInside === 'function')
          ? n.isPointInside(pointer.worldX, pointer.worldY)
          : dist(pointer.worldX, pointer.worldY, n.x, n.y) <= (n.r || 12);
        if (hit) { draggingNode = n; n.fixed = true;
          n.offsetX = pointer.worldX - n.x; n.offsetY = pointer.worldY - n.y;
          window.activeNode = n; break; }
      }
    }
  }

  pointer.down = true;
  pointer.startX = pointer.x; pointer.startY = pointer.y;
  pointer.dragging = false; pointer.tapCandidate = true;

  return false;
}

function touchMoved(ev) {
  if (overlayIsOpen() || uiWantsThisTouch(ev)) return true;
  if (pointer.id === null) return true;

  let t = null;
  for (const tt of touches) if (tt.id === pointer.id) { t = tt; break; }
  if (!t) return true;

  pointer.x = t.x; pointer.y = t.y;
  const w = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = w.x; pointer.worldY = w.y;

  if (!pointer.dragging) {
    const dx = pointer.x - pointer.startX, dy = pointer.y - pointer.startY;
    if (dx*dx + dy*dy > DRAG_SLOP*DRAG_SLOP) {
      pointer.dragging = true; pointer.tapCandidate = false;
      if (draggingTag) draggingTag.dragging = true;
    }
  }

  if (pointer.dragging) {
    if (inTagStage() && draggingTag) {
      draggingTag.x = pointer.worldX - draggingTag.dx;
      draggingTag.y = pointer.worldY - draggingTag.dy;
      draggingTag.vx = 0; draggingTag.vy = 0;
    } else if (window.mode === 'graph' && draggingNode) {
      draggingNode.x = pointer.worldX - draggingNode.offsetX;
      draggingNode.y = pointer.worldY - draggingNode.offsetY;
      draggingNode.vx = 0; draggingNode.vy = 0;
    }
  }

  return false;
}

function touchEnded(ev) {
  if (overlayIsOpen() || uiWantsThisTouch(ev)) return true;

  if (pointer.x != null && pointer.y != null) {
    const w = screenToWorld(pointer.x, pointer.y);
    pointer.worldX = w.x; pointer.worldY = w.y;
  }

  if (inTagStage()) {
    if (draggingTag) {
      draggingTag.dragging = false;
      if (inDrop(pointer.x, pointer.y)) {
        const maxSel = (window.UI && Number.isFinite(UI.maxSelected)) ? UI.maxSelected : 3;
        if (!Array.isArray(window.selected)) window.selected = [];
        const already = selected.some(s => (s.label || s) === draggingTag.label);
        if (!already && selected.length < maxSel) {
          selected.push({ label: draggingTag.label, tags: draggingTag.tags?.slice?.() || [] });
        }
      }
      draggingTag = null;
      finishPointerGesture();
      return false;
    }

    // SELECT: tap play
    if (window.mode === 'select' && pointer.tapCandidate) {
      if (isOnPlayButton(pointer.x, pointer.y) &&
          Array.isArray(window.selected) &&
          selected.length > 0 && selected.length <= ((window.UI && UI.maxSelected) || 3)) {
        if (typeof window.launchGraphFromSelection === 'function') window.launchGraphFromSelection();
      }
    }

    finishPointerGesture();
    return false;
  }

  if (window.mode === 'graph') {
    if (!draggingNode) {
      let tapped = null;
      if (Array.isArray(window.nodes)) {
        for (const n of nodes) {
          const hit = (typeof n.isPointInside === 'function')
            ? n.isPointInside(pointer.worldX, pointer.worldY)
            : dist(pointer.worldX, pointer.worldY, n.x, n.y) <= (n.r || 12);
          if (hit) { tapped = n; break; }
        }
      }
      if (tapped) {
        if (typeof window.refocusToByTags === 'function') window.refocusToByTags(tapped);
        else if (typeof window.refocusTo === 'function') window.refocusTo(tapped);
        if (typeof window.centerCameraOnNode === 'function') centerCameraOnNode(window.centerNode);
      }
    } else {
      draggingNode.fixed = false; draggingNode = null;
    }
    if (ev && typeof ev.preventDefault === 'function') ev.preventDefault();
    finishPointerGesture();
    return false;
  }

  finishPointerGesture();
  return false;
}

function finishPointerGesture() {
  pointer.down = false;
  pointer.dragging = false;
  pointer.id = null;
}
