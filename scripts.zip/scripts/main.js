let acuminRegular;
let acuminLight;

function preload() {
  // Paths relative to index.html. No spaces; exact filenames.
  acuminLight   = loadFont('fonts/Acumin-Pro/Acumin-Pro-Light.otf',
                           () => console.log('Light loaded'),
                           err => console.error('Light failed:', err));

  acuminRegular = loadFont('fonts/Acumin-Pro/Acumin-Pro-Book.otf',
                           () => console.log('Book loaded'),
                           err => console.error('Book failed:', err));
}



if (typeof mode === 'undefined') {
  window.mode = 'landing';
} else {
  mode = 'landing';
}

if (!('landingSpawned' in window)) window.landingSpawned = false;
if (!('playLabelRect' in window))  window.playLabelRect  = null;


function setup() {
  createCanvas(windowWidth, windowHeight);
  sizeToViewport();                     
  textFont('monospace');
  noCursor();
  textAlign(CENTER, CENTER);

  UI = getUIConfig();
  baseWidth = UI.baseWidth;
  baseHeight = UI.baseHeight;

  pointer.isTouch = isMobileViewport();

  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', sizeToViewport);
    window.visualViewport.addEventListener('scroll', sizeToViewport); // ← add this too
  }

  computeTopBar();
  computeTransform();

  centerNode = new GraphNode("•", baseWidth / 2, baseHeight / 2, [], true);
  centerNode.fixed = true;
  activeNode = centerNode;

  setupSelectUI();
  spawnFloatingTags();
}


function sizeToViewport() {
  const vv = window.visualViewport;
  const w = vv ? Math.round(vv.width)  : windowWidth;
  const h = vv ? Math.round(vv.height) : windowHeight;
  resizeCanvas(w, h);
}


function windowResized() {
  // resizeCanvas(windowWidth, windowHeight);  
  sizeToViewport();
  UI = getUIConfig();
  baseWidth = UI.baseWidth;
  baseHeight = UI.baseHeight;
  pointer.isTouch = isMobileViewport();

  computeTopBar();
  computeTransform();
  setupSelectUI();
}

function draw() {
  background(COLORS.bg);

  if (mode !== 'landing') drawTopBar();


  // update world pointer
  const wpt = screenToWorld(pointer.x, pointer.y);
  pointer.worldX = wpt.x; pointer.worldY = wpt.y;

  // after updating pointer.worldX/Y


if (mode === 'landing') {
  drawLandingUI();
} else if (mode === 'select') {
  // (Optional) If you still keep a select stage later,
  // you can reuse your old block here without the Play button.
  for (const n of tagNodes) { n.resetForces(); n.applyRepulsion(tagNodes); }
  for (const n of tagNodes) n.update();

  push(); translate(worldOffsetX, worldOffsetY); scale(scaleFactor);
  drawDropZone(); for (const n of tagNodes) n.display(); pop();

  // drawPlayButton(); // <- removed per your request
} else {
  runGraph();
}


  if (!isMobileViewport()) {
    noCursor();
    fill(COLORS.blue); noStroke();
    circle(pointer.x, pointer.y, 20);
    } else {
    cursor(ARROW); // normal touch/drag, no custom circle cursor
    }

  if (pointer.justReleased) pointer.justReleased = false;
}

// ---- SAFE VIEWPORT HELPERS (header + blue panel aware) ----
(function () {
  if (typeof window.getHeaderHeight !== 'function') {
    window.getHeaderHeight = function () {
      try {
        const sels = ['header', '.header', '#header', '.site-header', '.topbar', '.navbar', '.app-header', '.nav'];
        let h = 0;
        for (const s of sels) {
          const el = document.querySelector(s);
          if (el) {
            const r = el.getBoundingClientRect();
            h = Math.max(h, (r && (r.height || (r.bottom - r.top))) || 0);
          }
        }
        return h;
      } catch { return 0; }
    };
  }

  // ---- Viewport helpers (landing ignores panels completely) ----
(function () {
  window.getGraphViewport = function () {
    // On landing, do NOT subtract sidebars/topbars; center in the full canvas
    if (window.mode === 'landing') {
      return { x: 0, y: 0, w: width, h: height };
    }

    const hasLeft   = (typeof LAYOUT !== 'undefined' && LAYOUT === 'left');
    const hasTop    = (typeof LAYOUT !== 'undefined' && LAYOUT === 'top');
    const hasBottom = (typeof LAYOUT !== 'undefined' && LAYOUT === 'bottom');

    const leftW   = hasLeft   ? (typeof sideBarW === 'number' ? sideBarW : 0) : 0;
    const topH    = hasTop    ? (typeof topBarH  === 'number' ? topBarH  : 0) : 0;
    const bottomH = hasBottom ? (typeof topBarH  === 'number' ? topBarH  : 0) : 0;

    // Canvas coords already start at the top of the canvas; don't subtract DOM header here.
    const x = leftW;
    const y = topH;
    const w = Math.max(0, width  - leftW);
    const h = Math.max(0, height - (hasLeft ? 0 : (topH + bottomH)));
    return { x, y, w, h };
  };
})();


  if (typeof window.getGraphViewport !== 'function') {
    window.getGraphViewport = function () {
      const hasLeft   = (typeof LAYOUT !== 'undefined' && LAYOUT === 'left');
      const hasTop    = (typeof LAYOUT !== 'undefined' && LAYOUT === 'top');
      const hasBottom = (typeof LAYOUT !== 'undefined' && LAYOUT === 'bottom');

      const leftW   = hasLeft   ? (typeof sideBarW === 'number' ? sideBarW : 0) : 0;
      const topH    = hasTop    ? (typeof topBarH  === 'number' ? topBarH  : 0) : 0;
      const bottomH = hasBottom ? (typeof topBarH  === 'number' ? topBarH  : 0) : 0;
      const headerH = window.getHeaderHeight ? window.getHeaderHeight() : 0;

      const W = (typeof width  === 'number') ? width  : 0;
      const H = (typeof height === 'number') ? height : 0;

      const x = leftW;
      const y = headerH + topH;                             // push down by header + top panel
      const w = Math.max(0, W - leftW);                    // remove left panel
      const h = Math.max(0, H - headerH - (hasLeft ? 0 : (topH + bottomH))); // remove top/bottom panels
      return { x, y, w, h };
    };
  }
})();



function drawLandingUI() {
  const vp = window.getGraphViewport();

  // Split white area: left text column + right circle column
  const leftW  = Math.max(360, Math.min(520, Math.round(vp.w * 0.42)));
  const rightW = Math.max(0, vp.w - leftW);

  // Drop circle centered in the RIGHT column
  const cx = vp.x + leftW + rightW * 0.5;
  const cy = vp.y + vp.h * 0.5;
  const diameter = Math.max(120, Math.min(rightW, vp.h) * 0.35);
  const radius   = diameter * 0.5;

  // Expose the drop zone for your existing logic
  window.dropZone = { x: cx - radius, y: cy - radius, w: diameter, h: diameter };
  window.dropCenter = { cx, cy }; // for other UI to align to

  // First frame: spawn tags from the circle center
  if (!landingSpawned && Array.isArray(tagNodes) && tagNodes.length) {
        const p = screenToWorld(cx, cy); // <- single correct transform
       for (const n of tagNodes) {
          n.x = p.x + random(-5, 5);
          n.y = p.y + random(-5, 5);
          n.vx = 0; n.vy = 0;
        }
        landingSpawned = true;
      }

  // --- physics & draw tags in WORLD space (same as your select branch)
  for (const n of tagNodes) { n.resetForces(); n.applyRepulsion(tagNodes); }
  for (const n of tagNodes) n.update();

  push();
  translate(worldOffsetX, worldOffsetY);
  scale(scaleFactor);
  for (const n of tagNodes) n.display();
  pop();

  // --- LEFT column: title + picked tags
  const leftPad = 24;
  const tx = vp.x + leftPad;
  const tw = leftW - leftPad * 2;

  noStroke();
  fill(COLORS.blue);
  textAlign(LEFT, TOP);
  textSize(28);
  text("Pick projects by tags and explore relations", tx, vp.y + 24, tw);

  // Selected tags as lime pills
  let px = tx, py = vp.y + 24 + 42;
  const pillH = 26, padX = 12, gap = 10;
  textSize(14);
  for (const s of (selected || [])) {
    const label = (s.label || s).toUpperCase();
    const w = textWidth(label) + padX * 2;
    if (px + w > tx + tw) { px = tx; py += pillH + gap; }
    fill(COLORS.lime); rect(px, py, w, pillH, pillH / 2);
    fill(COLORS.blue); textAlign(CENTER, CENTER); text(label, px + w / 2, py + pillH / 2 + 1);
    px += w + gap;
  }

  // --- RIGHT column: drop circle + text "button"
  push();
  resetMatrix(); // draw in screen coordinates
  noStroke(); fill(COLORS.blue); ellipse(cx, cy, diameter, diameter);

  fill(255);
  textAlign(CENTER, CENTER);
  textSize(Math.max(16, diameter * 0.22));
  text(`${(selected && selected.length) || 0}/3`, cx, cy);

  fill(COLORS.blue);
  textSize(14);
  const label = "PRESS HERE WHEN YOU'RE DONE";
  const labelY = cy + radius + 28;
  text(label, cx, labelY);

  // clickable area for the label
  const lw = textWidth(label);
  playLabelRect = { x: cx - lw / 2 - 6, y: labelY - 12, w: lw + 12, h: 24 };
  pop();

  // Click to proceed
  if (pointer.justReleased && playLabelRect &&
      pointer.x >= playLabelRect.x && pointer.x <= playLabelRect.x + playLabelRect.w &&
      pointer.y >= playLabelRect.y && pointer.y <= playLabelRect.y + playLabelRect.h) {
    proceedToGraph();
  }
}
function proceedToGraph() {
  // Call your existing builder if present; otherwise just switch modes.
  if (typeof onPlaySelected === 'function') { onPlaySelected(); return; }
  if (typeof buildGraphFromSelected === 'function') { buildGraphFromSelected(); }
  mode = 'graph';
  // If you used to switch to "select" first, change the line above accordingly.
}

